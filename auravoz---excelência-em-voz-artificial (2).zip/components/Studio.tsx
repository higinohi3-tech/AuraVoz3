
import React, { useState, useRef, useEffect } from 'react';
import { generateTTS, playAudioBuffer } from '../services/geminiService';
import { EMOTIONS, LANGUAGES, VOICE_TYPES, GENDERS } from '../constants';
import { VoiceGender, AppSection } from '../types';

const RECORDING_SCRIPTS = [
  "O futuro da comunicação em Angola está sendo escrito agora com a AuraVoz.",
  "Minha voz digital me permite estar presente em múltiplos lugares ao mesmo tempo.",
  "Mantenho a autenticidade e o carinho em cada palavra dita aos meus clientes.",
  "A inteligência artificial humanizada é uma ferramenta poderosa para o progresso.",
  "Estou gravando esta amostra para que minha identidade vocal seja preservada.",
  "A inovação tecnológica nos aproxima e cria novas oportunidades para todos.",
  "Com a AuraVoz, as fronteiras da linguagem e da distância desaparecem.",
  "Valorizo a clareza e a emoção em todas as minhas interações digitais.",
  "A tecnologia deve servir às pessoas e honrar as nossas tradições culturais.",
  "Este é um novo capítulo na história da tecnologia em Luanda e além."
];

interface StudioProps {
  onSwitchSection?: (section: AppSection) => void;
  isConcentrated?: boolean;
  setIsConcentrated?: (value: boolean) => void;
}

const Studio: React.FC<StudioProps> = ({ onSwitchSection, isConcentrated, setIsConcentrated }) => {
  const [text, setText] = useState('');
  const [emotion, setEmotion] = useState('Alegre');
  const [gender, setGender] = useState<VoiceGender>('Feminino');
  const [language, setLanguage] = useState('Português (Angola)');
  const [voiceType, setVoiceType] = useState('Normal');
  const [isGenerating, setIsGenerating] = useState(false);
  const [name, setName] = useState('');
  const [isCloningMode, setIsCloningMode] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [cloningStep, setCloningStep] = useState<'intro' | 'recording' | 'processing' | 'success'>('intro');
  
  const timerRef = useRef<number | null>(null);
  const accountNum = "4220360093643975";

  const handleGenerate = async () => {
    if (!text.trim()) return;
    setIsGenerating(true);
    
    let processedText = text;
    if (name) {
      processedText = text.replace(/\[NOME\]/gi, name);
    }

    const voiceName = gender === 'Feminino' ? 'Kore' : 'Puck';
    const instruction = `Gere uma voz do gênero ${gender} em ${language}, com emoção ${emotion}, no estilo ${voiceType}.`;
    
    const buffer = await generateTTS(processedText, instruction, voiceName);
    if (buffer) {
      playAudioBuffer(buffer);
    }
    setIsGenerating(false);
  };

  const startCloningFlow = () => {
    setIsCloningMode(true);
    setCloningStep('intro');
  };

  const startRecording = () => {
    setCloningStep('recording');
    setIsRecording(true);
    setRecordingTime(0);
    timerRef.current = window.setInterval(() => {
      setRecordingTime(prev => prev + 1);
    }, 1000);
  };

  const stopRecording = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setIsRecording(false);
    setCloningStep('processing');
    
    // Simular processamento da clonagem
    setTimeout(() => {
      setCloningStep('success');
    }, 3000);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const toggleConcentrated = () => {
    if (setIsConcentrated) setIsConcentrated(!isConcentrated);
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  // Calcular frase atual e progresso do ciclo de 8 segundos
  const currentScriptIndex = Math.floor(recordingTime / 8) % RECORDING_SCRIPTS.length;
  const cycleProgress = (recordingTime % 8) / 8 * 100;

  if (isConcentrated) {
    return (
      <div className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center p-6 animate-in fade-in duration-700">
        <div className="absolute top-8 left-8 flex items-center gap-3">
          <div className="w-8 h-8 bg-violet-600 rounded-lg flex items-center justify-center shadow-lg shadow-violet-500/20">
            <i className="fa-solid fa-waveform text-white text-xs"></i>
          </div>
          <span className="text-sm font-bold uppercase tracking-[0.3em] text-zinc-500">AuraVoz <span className="text-violet-500">Zen</span></span>
        </div>

        <button 
          onClick={toggleConcentrated}
          className="absolute top-8 right-8 text-zinc-600 hover:text-white transition-all flex items-center gap-2 group"
        >
          <span className="text-[10px] font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">Sair do Modo Zen</span>
          <i className="fa-solid fa-compress text-xl"></i>
        </button>

        <div className="w-full max-w-4xl space-y-8">
          <textarea 
            className="w-full h-[60vh] bg-transparent border-none text-2xl md:text-4xl text-zinc-200 focus:ring-0 outline-none resize-none placeholder:text-zinc-900 custom-scrollbar text-center font-light leading-relaxed"
            placeholder="Apenas as suas palavras importam aqui..."
            value={text}
            onChange={(e) => setText(e.target.value)}
            autoFocus
          />
          
          <div className="flex flex-col items-center gap-6">
            <div className="flex gap-6 text-zinc-600 text-xs font-bold uppercase tracking-widest">
              <span>{text.split(/\s+/).filter(Boolean).length} palavras</span>
              <span className="text-zinc-800">|</span>
              <span>{emotion} • {gender} • {language}</span>
            </div>
            
            <button 
              onClick={handleGenerate}
              disabled={isGenerating || !text.trim()}
              className={`group flex items-center gap-4 bg-white text-black font-black px-12 py-5 rounded-full shadow-2xl transition-all ${isGenerating || !text.trim() ? 'opacity-10 cursor-not-allowed' : 'hover:scale-105 active:scale-95 hover:bg-violet-500 hover:text-white'}`}
            >
              {isGenerating ? (
                <><i className="fa-solid fa-circle-notch animate-spin"></i> CRIANDO...</>
              ) : (
                <><i className="fa-solid fa-play text-xl group-hover:animate-pulse"></i> DAR VOZ AO TEXTO</>
              )}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-12 max-w-6xl mx-auto px-4 animate-in fade-in duration-500">
      <div className="bg-zinc-900 rounded-[2.5rem] shadow-2xl overflow-hidden border border-zinc-800 mb-8 relative">
        
        {/* Voice Cloning Overlay */}
        {isCloningMode && (
          <div className="absolute inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-6 text-center animate-in fade-in duration-300">
            <button 
              onClick={() => setIsCloningMode(false)}
              className="absolute top-6 right-6 text-zinc-500 hover:text-white transition-colors"
            >
              <i className="fa-solid fa-xmark text-2xl"></i>
            </button>

            <div className="max-w-md w-full">
              {cloningStep === 'intro' && (
                <div className="space-y-6">
                  <div className="w-20 h-20 bg-violet-600/20 rounded-3xl flex items-center justify-center mx-auto mb-6 border border-violet-500/30">
                    <i className="fa-solid fa-id-card-clip text-3xl text-violet-400"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-white">Clonagem de Voz</h3>
                  <p className="text-zinc-400">Para criar um clone perfeito, precisamos que você grave de 1 a 3 minutos da sua voz lendo um texto sugerido.</p>
                  <div className="bg-zinc-900 p-4 rounded-2xl border border-zinc-800 text-left text-sm space-y-3">
                    <p className="flex items-center gap-3 text-zinc-300">
                      <i className="fa-solid fa-microphone-lines text-violet-500"></i>
                      Ambiente silencioso
                    </p>
                    <p className="flex items-center gap-3 text-zinc-300">
                      <i className="fa-solid fa-bolt text-violet-500"></i>
                      Voz natural e clara
                    </p>
                  </div>
                  <button 
                    onClick={startRecording}
                    className="w-full py-4 bg-violet-600 text-white rounded-2xl font-bold hover:bg-violet-700 transition-all shadow-xl shadow-violet-500/20"
                  >
                    COMEÇAR GRAVAÇÃO
                  </button>
                </div>
              )}

              {cloningStep === 'recording' && (
                <div className="space-y-6">
                  <div className="relative">
                    <div className="absolute inset-0 bg-red-500/20 rounded-full blur-2xl animate-pulse"></div>
                    <div className="w-24 h-24 bg-red-600 rounded-full flex items-center justify-center mx-auto mb-4 relative z-10 shadow-xl shadow-red-900/40">
                      <i className="fa-solid fa-microphone text-3xl text-white"></i>
                    </div>
                  </div>
                  <div className="text-3xl font-mono font-bold text-white mb-2">{formatTime(recordingTime)}</div>
                  <p className="text-zinc-500 text-[10px] font-black uppercase tracking-[0.2em] mb-4">Gravando amostra vocal...</p>
                  
                  <div className="bg-zinc-900/50 rounded-3xl border border-zinc-800 text-left mb-6 overflow-hidden shadow-inner relative group">
                    {/* Progress indicator for the 8s cycle */}
                    <div className="absolute top-0 left-0 h-1 bg-violet-500 transition-all duration-1000" style={{ width: `${cycleProgress}%` }}></div>
                    
                    <div className="p-8 italic text-white text-lg leading-relaxed min-h-[160px] flex items-center justify-center text-center animate-in fade-in slide-in-from-right-2 duration-500" key={currentScriptIndex}>
                      "{RECORDING_SCRIPTS[currentScriptIndex]}"
                    </div>
                  </div>

                  <div className="flex gap-2 justify-center mb-8">
                    {RECORDING_SCRIPTS.slice(0, 5).map((_, i) => (
                      <div key={i} className={`h-1 rounded-full transition-all duration-500 ${i === currentScriptIndex % 5 ? 'w-8 bg-violet-500' : 'w-2 bg-zinc-800'}`}></div>
                    ))}
                  </div>

                  <button 
                    onClick={stopRecording}
                    className="w-full py-4 bg-white text-black rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-zinc-200 transition-all active:scale-95"
                  >
                    FINALIZAR E PROCESSAR
                  </button>
                </div>
              )}

              {cloningStep === 'processing' && (
                <div className="space-y-8 py-10">
                  <div className="relative w-32 h-32 mx-auto">
                    <div className="absolute inset-0 border-4 border-violet-500/20 rounded-full"></div>
                    <div className="absolute inset-0 border-4 border-violet-500 border-t-transparent rounded-full animate-spin"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <i className="fa-solid fa-brain text-4xl text-violet-400 animate-pulse"></i>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-2">Criando seu Clone</h3>
                    <p className="text-zinc-500 text-sm">Nossa rede neural está processando as nuances da sua voz...</p>
                  </div>
                  <div className="w-full bg-zinc-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-violet-500 h-full animate-pulse" style={{ width: '75%' }}></div>
                  </div>
                </div>
              )}

              {cloningStep === 'success' && (
                <div className="space-y-6">
                  <div className="w-24 h-24 bg-emerald-600/20 rounded-full flex items-center justify-center mx-auto mb-6 border border-emerald-500/30 shadow-lg shadow-emerald-500/10">
                    <i className="fa-solid fa-check text-4xl text-emerald-400"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-white">Voz Clonada com Sucesso!</h3>
                  <p className="text-zinc-400">Seu perfil vocal agora está disponível nas opções de vozes do estúdio.</p>
                  <button 
                    onClick={() => setIsCloningMode(false)}
                    className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all"
                  >
                    VOLTAR AO ESTÚDIO
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        <div className="md:flex">
          {/* Controls Sidebar */}
          <div className="w-full md:w-1/3 bg-zinc-950 p-10 border-r border-zinc-800">
            <h2 className="text-xl font-bold mb-8 flex items-center text-white">
              <i className="fa-solid fa-sliders mr-3 text-violet-500"></i>
              Configuração
            </h2>

            <div className="space-y-8">
              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase tracking-widest mb-3">Gênero</label>
                <div className="flex p-1 bg-zinc-900 border border-zinc-800 rounded-2xl">
                  {GENDERS.map(g => (
                    <button
                      key={g}
                      onClick={() => setGender(g as VoiceGender)}
                      className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-all ${gender === g ? 'bg-violet-600 text-white shadow-lg' : 'text-zinc-500 hover:text-zinc-300'}`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase tracking-widest mb-3">Voz Selecionada</label>
                <div className="relative">
                  <select 
                    value={emotion}
                    onChange={(e) => setEmotion(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl px-5 py-3 text-white focus:ring-2 focus:ring-violet-500 outline-none transition-all appearance-none"
                  >
                    {EMOTIONS.map(e => <option key={e} value={e}>{e}</option>)}
                    {cloningStep === 'success' && <option value="Meu Clone">Meu Clone Vocal 🎙️</option>}
                  </select>
                  <i className="fa-solid fa-chevron-down absolute right-5 top-1/2 -translate-y-1/2 text-zinc-600 pointer-events-none"></i>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase tracking-widest mb-3">Idioma</label>
                <select 
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl px-5 py-3 text-white focus:ring-2 focus:ring-violet-500 outline-none transition-all"
                >
                  {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
                </select>
              </div>

              <div className="pt-4 space-y-3">
                <button 
                  onClick={startCloningFlow}
                  className="w-full py-4 border-2 border-violet-500/30 text-violet-400 rounded-2xl font-bold hover:bg-violet-500/10 transition-all flex items-center justify-center gap-3 group"
                >
                  <i className="fa-solid fa-microphone-lines group-hover:scale-110 transition-transform"></i>
                  CLONAR MINHA VOZ
                </button>
                <button 
                  onClick={toggleConcentrated}
                  className="w-full py-4 bg-zinc-800 text-zinc-400 rounded-2xl font-bold hover:bg-zinc-700 transition-all flex items-center justify-center gap-3 group"
                >
                  <i className="fa-solid fa-expand group-hover:scale-110 transition-transform"></i>
                  MODO CONCENTRADO
                </button>
              </div>
            </div>
          </div>

          {/* Editor Area */}
          <div className="w-full md:w-2/3 p-10 bg-zinc-900">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">Estúdio AuraVoz</h2>
              <div className="flex gap-3">
                <button 
                  onClick={() => onSwitchSection?.(AppSection.VISION)}
                  className="bg-cyan-600/10 hover:bg-cyan-600/20 text-cyan-400 px-4 py-2 rounded-xl text-xs font-bold border border-cyan-500/20 transition-all flex items-center"
                >
                  <i className="fa-solid fa-camera mr-2"></i>
                  IMPORTAR FOTO
                </button>
              </div>
            </div>
            
            <textarea 
              className="w-full h-[400px] bg-zinc-950/50 border border-zinc-800 rounded-3xl p-8 text-lg text-zinc-200 focus:ring-2 focus:ring-violet-500 outline-none resize-none mb-8 placeholder:text-zinc-800 shadow-inner"
              placeholder="Digite ou cole aqui o texto que você deseja transformar em voz com alma..."
              value={text}
              onChange={(e) => setText(e.target.value)}
            />

            <div className="flex items-center justify-between">
              <div className="text-xs font-bold text-zinc-600 uppercase tracking-widest">
                {text.length} caracteres digitados
              </div>
              <button 
                onClick={handleGenerate}
                disabled={isGenerating || !text.trim()}
                className={`flex items-center gap-3 bg-violet-600 text-white font-bold px-10 py-4 rounded-2xl shadow-2xl shadow-violet-500/20 transition-all ${isGenerating || !text.trim() ? 'opacity-30 cursor-not-allowed' : 'hover:bg-violet-700 active:scale-95'}`}
              >
                {isGenerating ? (
                  <><i className="fa-solid fa-spinner animate-spin"></i> PROCESSANDO...</>
                ) : (
                  <><i className="fa-solid fa-play"></i> GERAR VOZ AGORA</>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-zinc-950 border border-violet-500/20 rounded-[2rem] p-8 flex flex-col md:flex-row items-center justify-between gap-8">
        <div className="flex items-center gap-5">
          <div className="w-16 h-16 bg-violet-600/10 border border-violet-500/20 rounded-2xl flex items-center justify-center text-2xl text-violet-400 shadow-inner">
            <i className="fa-solid fa-bolt"></i>
          </div>
          <div>
            <h4 className="font-bold text-xl text-white">Créditos de Produção</h4>
            <p className="text-zinc-500">Recarregue para remover o limite de caracteres diários.</p>
          </div>
        </div>
        <div className="bg-black/40 px-8 py-4 rounded-2xl border border-zinc-800 text-center">
          <p className="text-[10px] text-violet-400 uppercase font-bold mb-1 tracking-[0.2em]">IBAN AuraVoz:</p>
          <p className="text-2xl font-mono font-bold text-white select-all">{accountNum}</p>
        </div>
      </div>
    </div>
  );
};

export default Studio;
